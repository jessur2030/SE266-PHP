<?php
     include __DIR__ . '/model/model_DisneyVotes.php';
     include __DIR__ . '/functions.php';
     
     $votes = getVotes();
     echo $votes;
     
     
     
?>

